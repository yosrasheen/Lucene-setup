<?php

$options = array('secure' => false);

$client = new SolrClient($options);

var_dump($client->getOptions());

?>
